#ifndef __GPIO_H
#define	__GPIO_H

#include "stm32f10x.h"

void Gpio_Init(void);


#endif

